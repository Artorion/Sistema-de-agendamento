/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package util;

import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

public class ConexaoBanco {
    
    public static java.sql.Connection getConexao(){
    
        java.sql.Connection con = null;
        
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            
            con = java.sql.DriverManager.getConnection("jdbc:mysql://localhost:3306/Agenda","root","");
            
            if(con == null){
                System.out.println("Erro ao conectar com o banco de dados!!");
            }else{
                System.out.println("Conectado com sucesso!!");
            }
            
        } catch (ClassNotFoundException | java.sql.SQLException ex) {
            Logger.getLogger(ConexaoBanco.class.getName()).log(Level.SEVERE, null, ex);
        }
  
        return con;

    }
    
}
