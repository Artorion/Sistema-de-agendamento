/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

import dao.CadastroDao;
import model.Cadastro;


public class CadastroController {
    
    public static Cadastro login(String email, String senha) {
    CadastroDao dao = new CadastroDao();
    Cadastro cad = dao.buscarPorEmail(email);
    
    if (cad != null && cad.getSenha().equals(senha)) {
        return cad;
    }
    
    return null;
}
    
    public static boolean inserirUsuario(Cadastro cad){
    
        CadastroDao cadDao = new CadastroDao();
        
        if(cad.getId() == 0){
            cadDao.inserirUsuario(cad);
        }
    
        return true;
    }
    
}



