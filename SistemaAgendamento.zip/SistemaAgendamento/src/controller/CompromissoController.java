/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

import dao.CompromissoDao;
import java.util.List;
import model.Compromisso;


public class CompromissoController {
    
     public static boolean adicionar(Compromisso comp){
    
        CompromissoDao compDao = new CompromissoDao();
        
        if(comp.getId() == 0){
            compDao.adicionar(comp);
        }
    
        return true;
    
}
     
     public static List<Compromisso> listar(){
     
         CompromissoDao compDao = new CompromissoDao();
         return compDao.listar();
    
     }
     
     public static Compromisso buscarProduto(int id){
        CompromissoDao compDao = new CompromissoDao();
        return compDao.getProdutoById(id);
        
    }
     
    public static void excluirProduto(int id){
       CompromissoDao compDao = new CompromissoDao();
       compDao.delete(id);
        
    }
}
