/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import java.util.ArrayList;
import java.util.List;
import model.Compromisso;
import util.ConexaoBanco;

public class CompromissoDao {
   
    public void adicionar(Compromisso comp){
    
        String sql = "INSERT INTO Agenda.compromissos (titulo,descricao,data) VALUES (?,?,?)";
        java.sql.Connection con = null;
        java.sql.PreparedStatement psmt = null;
        
        try {
            con = ConexaoBanco.getConexao();
            psmt = con.prepareStatement(sql);
            
            psmt.setString(1, comp.getTitulo());
            psmt.setString(2, comp.getDescricao());
            psmt.setString(3, comp.getData());
            
            psmt.execute();
            
            con.close();
            
        }catch(java.sql.SQLException ex){
            throw new RuntimeException(ex.getMessage());
        }
    
    }
    
    public List<Compromisso> listar(){
    
        String sql = "Select * FROM Agenda.compromissos";
        java.sql.Connection con = null;
        java.sql.PreparedStatement psmt = null;
        java.sql.ResultSet rs = null;
        List<Compromisso> retorno = new ArrayList<>();
        
        try{
            con = ConexaoBanco.getConexao();
            psmt = con.prepareStatement(sql);
            rs = psmt.executeQuery();
            
            while(rs.next()){
               
                Compromisso comp = new Compromisso();
                comp.setId(rs.getInt("id"));
                comp.setTitulo(rs.getString("titulo"));
                comp.setDescricao(rs.getString("descricao"));
                comp.setData(rs.getString("data"));
                
                retorno.add(comp);   
            }
        
        }catch(java.sql.SQLException ex){
            throw new RuntimeException(ex.getMessage());
        }
        
         return retorno;
    }
    
    public void editar(Compromisso comp){
    
        String sql = "UPDATE Agenda.compromissos SET titulo = ?, descricao = ?, data = ? WHERE id = ?";
        
        java.sql.Connection con = null;
        java.sql.PreparedStatement psmt = null;
        try{
            con = ConexaoBanco.getConexao();
            psmt = con.prepareStatement(sql);
            
            psmt.setString(1, comp.getTitulo());
            psmt.setString(2, comp.getDescricao());
            psmt.setString(3, comp.getData());
            psmt.setInt(4, comp.getId());
            psmt.execute();
            
            con.close();   
            
        }catch(java.sql.SQLException ex){
            throw new RuntimeException(ex.getMessage());
        }
    }

    public Compromisso getProdutoById(int id) {
        
        String sql = "SELECT * FROM Agenda.compromissos WHERE id = ?";
        java.sql.Connection con = null;
        java.sql.PreparedStatement psmt = null;
        java.sql.ResultSet rs = null;
        Compromisso comp = new Compromisso();

        
        try{
        
            con = ConexaoBanco.getConexao();
            psmt = con.prepareStatement(sql);
            psmt.setInt(1, id);
            rs = psmt.executeQuery();
            
            while(rs.next()){
            
                comp.setId(rs.getInt("id"));
                comp.setTitulo(rs.getString("titulo"));
                comp.setDescricao(rs.getString("descricao"));
                comp.setData(rs.getString("data"));
            
            }
            
        }catch(java.sql.SQLException ex){
            throw new RuntimeException(ex.getMessage());
        }
        
        return comp;
        
    }
    
    public void delete(int id){
    
        String sql = "DELETE FROM Agenda.compromissos WHERE id = ?";
        java.sql.Connection con = null;
        java.sql.PreparedStatement psmt = null;
        
        try{
        
            con = ConexaoBanco.getConexao();
            psmt = con.prepareStatement(sql);
            psmt.setInt(1, id);
            psmt.execute();

        }catch(java.sql.SQLException ex){
            throw new RuntimeException(ex.getMessage());
        }
        
    }    
    
}
