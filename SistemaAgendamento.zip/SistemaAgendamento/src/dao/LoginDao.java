/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import util.ConexaoBanco;

/**
 *
 * @author Desktop
 */
public class LoginDao {
    
    public boolean autenticar(String email, String senha){
    
        String sql = "SELECT senha FROM usuario WHERE senha = ?";
        java.sql.Connection con = null;
        java.sql.PreparedStatement psmt = null;
        java.sql.ResultSet rs = null;
    
    try{
            con = ConexaoBanco.getConexao();
            psmt = con.prepareStatement(sql);
            psmt.setString(1, email);
            rs = psmt.executeQuery();
            
            if(rs.next()){
                String senhaBanco = rs.getString("senha");
                return senhaBanco.equals(senha);  
            }
        
        
        
        }catch(java.sql.SQLException ex){
            throw new RuntimeException(ex.getMessage());
        }
    
        return false;
   }
    
}
