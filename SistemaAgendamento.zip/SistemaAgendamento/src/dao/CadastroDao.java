/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import model.Cadastro;
import util.ConexaoBanco;

public class CadastroDao {
    
    public void inserirUsuario(Cadastro cad){
    
        String sql = "INSERT INTO Agenda.usuario (nome,email,senha) VALUES (?,?,?)";
        java.sql.Connection con = null;
        java.sql.PreparedStatement psmt = null;
        
        try {
            con = ConexaoBanco.getConexao();
            psmt = con.prepareStatement(sql);
            
            psmt.setString(1, cad.getNome());
            psmt.setString(2, cad.getEmail());
            psmt.setString(3, cad.getSenha());
            
            psmt.execute();
            
            con.close();
            
        }catch(java.sql.SQLException ex){
            throw new RuntimeException(ex.getMessage());
        }
    
    }
    
}
