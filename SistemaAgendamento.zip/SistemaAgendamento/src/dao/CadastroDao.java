/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import model.Cadastro;
import util.ConexaoBanco;

public class CadastroDao {
    
    public void inserirUsuario(Cadastro cad){
        String sql = "INSERT INTO Agenda.usuario (nome,email,senha) VALUES (?,?,?)";
        
        try (java.sql.Connection con = ConexaoBanco.getConexao();
             java.sql.PreparedStatement psmt = con.prepareStatement(sql)) {
            
            psmt.setString(1, cad.getNome());
            psmt.setString(2, cad.getEmail());
            psmt.setString(3, cad.getSenha());
            psmt.execute();
            
        } catch (java.sql.SQLException ex) {
            throw new RuntimeException(ex.getMessage());
        }
    }
    
    public Cadastro buscarPorEmail(String email) {
        String sql = "SELECT * FROM Agenda.usuario WHERE email = ?";
        
        try (java.sql.Connection con = ConexaoBanco.getConexao();
             java.sql.PreparedStatement psmt = con.prepareStatement(sql)) {
            
            psmt.setString(1, email);
            java.sql.ResultSet rs = psmt.executeQuery();
            
            if (rs.next()) {
                Cadastro cad = new Cadastro();
                cad.setNome(rs.getString("nome"));
                cad.setEmail(rs.getString("email"));
                cad.setSenha(rs.getString("senha"));
                return cad;
            }
            
        } catch (java.sql.SQLException ex) {
            throw new RuntimeException(ex.getMessage());
        }
        
        return null;
    }
}
